﻿using System;
using System.Threading.Tasks;

namespace WebClient
{
    static class Program
    {
        static Task Main(string[] args)
        {
            throw new NotImplementedException();
        }

        private static CustomerCreateRequest RandomCustomer()
        {
            throw new NotImplementedException();
        }
    }
}